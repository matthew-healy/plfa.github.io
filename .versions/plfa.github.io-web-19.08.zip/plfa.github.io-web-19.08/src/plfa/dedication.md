---
title     : "Dedication"
layout    : page
permalink : /Dedication/
next      : /Preface/
---

<center>
<h2>To Wanda</h2>
<h3><em>amor da minha vida</em></h3>
<h4><em>knock knock knock</em></h4>
</center>
