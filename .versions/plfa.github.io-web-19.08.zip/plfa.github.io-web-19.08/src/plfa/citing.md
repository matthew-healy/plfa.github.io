---
title          : How to Cite this Book
layout         : page
permalink      : /Citing/
---

### Chicago

> Wadler, Philip and Wen Kokke.
> _Programming Language Foundations in Agda_.
> Available at `http://plfa.inf.ed.ac.uk`.
> 2019.


### Bibtex

	@Book{plfa2019,
	  author = {Philip Wadler and Wen Kokke},
	  title  = {Programming Language Foundations in {A}gda},
	  note   = {Available at \url{http://plfa.inf.ed.ac.uk/}},
	  year   = 2019,
	}
