---
title     : "Dedication"
layout    : page
permalink : /Dedication/
next      : /Preface/
---

<p style="text-align:center;">
  <span style="font-size:1.5em">de Philip, para Wanda</span>
</p>

<p style="text-align:center;">
  <span style="font-size:1.17em">amor da minha vida</span>
</p>

<p style="text-align:center;">
  <span style="font-size:1em">knock knock knock</span>
</p>

<p style="text-align:center;">
  <span style="font-size:1em">...</span>
</p>
