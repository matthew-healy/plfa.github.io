---
layout : post
title  : "PLFA as EPUB"
---

It has been just over a year and a half since this feature was first requested in [#112][issue112]… Thanks to hard work by [Michael Reed][mreed20], and a little elbow grease on our part, it is finally here! [An EPUB version of PLFA!][epub]

[epub]: https://plfa.github.io/out/epub/plfa.epub
[issue112]: https://github.com/plfa/plfa.github.io/issues/112
[mreed20]: https://github.com/mreed20
